// import React, { useState } from 'react';
// import { Button } from '@mui/material';
// import axios from 'axios';

// const ImageUploader = ({ clientId }) => {
//   const [images, setImages] = useState([]);

//   const fetchImages = async () => {
//     try {
//       const response = await axios.get(`http://localhost:8080/client/${clientId}/images`);
//       setImages(response.data);
//     } catch (error) {
//       console.error(error);
//     }
//   };

//   return (
//     <div>
//       <Button variant="contained" color="primary" onClick={fetchImages}>
//         Load Saved Images
//       </Button>
//       <div>
//         {images.map((image, index) => (
//           <img key={index} src={image.url} alt={`client-${clientId}-image-${index}`} />
//         ))}
//       </div>
//     </div>
//   );
// };

// export default ImageUploader;
