import React, { useState } from 'react';
import { Button, Typography } from '@mui/material';
import ImageGallery from './ImageGallery';
// import axios from 'axios'; // Закомментируем, так как не используем

const ClientPage = ({ clientData }) => {
  const [selectedImage, setSelectedImage] = useState(null);

  const handleImageSelect = (image) => {
    setSelectedImage(image);
  };

  const handleSaveImage = async () => {
    try {
      // Закомментируем этот блок, чтобы избежать ошибки из-за отсутствия бэкенда
      // await axios.post(`http://localhost:8080/client/${clientData.id}/saveImage`, {
      //   image: selectedImage,
      // });
      alert('Image saved successfully!');
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div>
      <Typography variant="h5">Client ID: {clientData.id}</Typography>
      <ImageGallery images={clientData.images} onSelect={handleImageSelect} />
      {selectedImage && (
        <Button variant="contained" color="primary" onClick={handleSaveImage}>
          Save Selected Image
        </Button>
      )}
      <Button variant="contained" color="secondary" onClick={() => window.location.reload()}>
        Select Another Client
      </Button>
      <Button variant="contained" color="default" onClick={() => window.location.href = '/'}>
        Logout
      </Button>
    </div>
  );
};

export default ClientPage;
